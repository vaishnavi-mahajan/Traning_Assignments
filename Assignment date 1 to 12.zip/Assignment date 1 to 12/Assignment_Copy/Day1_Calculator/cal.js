function valuecal(result){
    calculatorForm.evalresult.value = calculatorForm.evalresult.value + result;
}