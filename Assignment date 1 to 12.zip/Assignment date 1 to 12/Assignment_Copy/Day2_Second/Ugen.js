function fn1()
{
   
    var rd1=document.getElementById("rd1");
    
    var rd2=document.getElementById("rd2");
    var rd2=document.getElementById("rd3");
    var rd2=document.getElementById("rd4");
    var rd2=document.getElementById("rd5");

    
}