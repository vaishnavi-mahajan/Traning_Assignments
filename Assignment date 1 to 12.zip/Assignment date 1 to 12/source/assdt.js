$('#input_starttime').pickatime({
    // Light or Dark theme
    darktheme: true
    });