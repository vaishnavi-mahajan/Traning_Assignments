const fs = require("fs");
const path = require("path");


const dirPath =path.join(__dirname,'./../files');

fs.mkdir(dirPath,(err)=>{
    if(err){
        console.log(`Error while creating directory ${err.message}`);
        return;
    }
    console.log('Directory created successfully!');
});



const filePath = path.join(__dirname,'./../files/myfile.txt');

 fs.writeFileSync(filePath,'Node.js is an open-source, cross-platform, back-end JavaScript runtime environment that runs on the V8 engine and executes JavaScript code outside a web browser. Node.js lets developers use JavaScript to write command line tools and for server-side scripting—running scripts server-side to produce dynamic web page content before the page is sent to the users web browser. Consequently, Node.js represents a JavaScript everywhere paradigm,[6] unifying web-application development around a single programming language, rather than different languages for server-side and client-side scripts.');





 fs.readdir(dirPath,(err,contents)=>{
    if(err){
        console.log(`Error Occured  in reading ${err.message}`);
        return;
    }
   
    contents.forEach((content,index)=>{
        fs.stat(`${dirPath}/${content}`, (error,stat)=>{
            if(error){
                console.log(`Error Occured  while reading ${error.message}`);
                return;
            }

            if(stat.isFile()) {
                // show file name
                console.log(`File Name = ${content}`);
                // read contents from file
                console.log(`Contents in ${content} is 
                              ${fs.readFileSync(`${dirPath}/${content}`)} `);
            }
        });
    });

    
});