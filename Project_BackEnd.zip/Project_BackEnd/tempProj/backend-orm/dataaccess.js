import { Sequelize } from "sequelize";

import pkg from "sequelize";

//import jsonwebtoken from "jsonwebtoken";

const { DataTypes } = pkg;

import role from "./models/role.js";
// import employees from "./models/employees.js";
import registration from "./models/registration.js";
import status from "./models/status.js";
import userinformation from "./models/userinformation.js";
// import vehicletypes from "./models/vehicletypes.js";
// import service from "./models/service"
import service from "./models/service.js";

import totalservices from "./models/totalservices.js";

import vehicleinfo from "./models/vehicleinfo.js";

import vehicletypes from "./models/vehicletypes.js";

const sequelize = new Sequelize("Project", "dbadmin", "Blaze@123", {
    host: "localhost",
    port: 5432,
    dialect: "postgres"
});

const jwtSettings = {

    jwtSecret: "123456",

};



class AuthLogic {

    constructor() {



        // employees.init(sequelize, DataTypes);

        role.init(sequelize, DataTypes);

        registration.init(sequelize, DataTypes);

        status.init(sequelize, DataTypes);

        userinformation.init(sequelize, DataTypes);

        service.init(sequelize, DataTypes);

        totalservices.init(sequelize, DataTypes);



    }

    async getServices(req, resp){

        // const user = req.body;

        console.log("GET");

        // await sequelize.sync({ force: false });

        const allServices = await service.findAll();

        console.log("GET");



        if (allServices !== null) {

            return resp.status(201).send({ message: `Username and pass is correct`,data:allServices});

        } else {

            return resp.status(409).send({ message: `No Data in Data base` });

        }

   

    }





    async ShowApi(req, resp) {
        console.log("API working")
        return resp.status(201).send({ message: `API called` });
    }

    async ShowApiPost(req, resp) {

        console.log(" post API working")
        console.log(req);
    }

    async bookService(req, resp) {

        const serv = req.body;

        if(serv != null){

        console.log("POST - BOOK SERVICE");

        console.log(serv);

        await sequelize.sync({ force: false });

       

        const serviceBooked = await registration.create({



            vehiclenumber: serv.vehiclenumber,

            customerid: serv.customerid,

            statusid: serv.statusid,

            serviceid: serv.serviceId,

            // city: serv.vehicletype,

        });


        console.log("-------------");

        console.log(serviceBooked );

        console.log("-------------");



        if (serviceBooked !== null) {

            console.log(serviceBooked.registrationid);

            const totalserv = await totalservices.create({



                vehicletypeid: serv.vehicleTypeId,

                // registrationid: serviceBooked.registrationid,

                serviceid: serv.serviceId,

                customerid: serv.customerid,

            });

            if (totalserv !== null) {

                console.log(totalserv);

            } else {

                return resp.status(409).send({ message: `No Data in Data base` });

            }




            return resp.status(201).send({ message: `Username and pass is correct`, data: serviceBooked.toJSON });

        } else {

            return resp.status(409).send({ message: `Incorrect Data` });

        }

        }

    }


    async getTotalServicesByCustomerId(req, resp){

        console.log("-------------------get serv customer id--------------");

        console.log(req.params.custId);

        const customerId = parseInt(req.params.custId);

        let custstring = customerId;

        console.log(custstring);

        console.log("-------------------get serv customer id--------------");

        await sequelize.sync({ force: false });

        const servicesForCustomer = await totalservices.findAll({

            where: { customerid: parseInt(req.params.custId) },

        });



        if (servicesForCustomer !== null) {

            return resp.status(201).send({ message: `Data received`, data: servicesForCustomer });

        } else {

            return resp.status(409).send({ message: `Incorrect Data` });

        }

   

    }

    // async login(req, resp) {
    //     const user = req.body;
    //     console.log("Post");
    //     console.log(user);
    //     await sequelize.sync({ force: false });
    //     const checkLogin = await userinformation.findOne({
    //         where: { email: user.email, userpassword: user.userpassword },
    //     });

    //     if (checkLogin !== null) {
    //         return resp.status(201).send({ message: `Username and pass is correct`, data: checkLogin.toJSON });
    //     } else {
    //         return resp.status(409).send({ message: `Incorrect Data` });
    //     }
    // }


    async login(req, resp) {

        const user = req.body;

        console.log("POst");

        console.log(user);

        await sequelize.sync({ force: false });

        const checkLogin = await userinformation.findOne({

            where: { email: user.email, userpassword: user.userpassword },

        });



        if (checkLogin !== null) {

            return resp.status(201).send({ message: `Username and pass is correct`, data: checkLogin});

        } else {

            return resp.status(409).send({ message: `Incorrect Data` });

        }

    }


    //   async bookService(req, resp) {

    //     const serv = req.body;

    //     if(serv != null){

    //     console.log("POST - BOOK SERVICE");

    //     console.log(serv);

    //     await sequelize.sync({ force: false });

       

    //     const serviceBooked = await registration.create({



    //         vehiclenumber: serv.vehiclenumber,

    //         customerid: serv.customerid,

    //         statusid: serv.statusid,

    //         serviceid: serv.serviceId,

    //         // city: serv.vehicletype,

    //     });


    //     console.log("-------------");

    //     console.log(serviceBooked );

    //     console.log("-------------");

    //     if (serviceBooked !== null) {

    //         console.log(serviceBooked.registrationid);

    //         const totalserv = await totalservices.create({



    //             vehicletypeid: serv.vehicleTypeId,

    //             registrationid: serviceBooked.registrationid,

    //             serviceid: serv.serviceId,

    //             // city: serv.vehicletype,

    //         });

    //         if (totalserv !== null) {

    //             console.log(totalserv);

    //         } else {

    //             return resp.status(409).send({ message: `No Data in Data base` });

    //         }




    //         return resp.status(201).send({ message: `Username and pass is correct`, data: serviceBooked.toJSON });

    //     } else {

    //         return resp.status(409).send({ message: `Incorrect Data` });

    //     }

    //     }

    // }


    //   async createService(req, resp) {
    //     let body = req.body;
    //     await sequelize.sync({ force: false });
    //     const ser = await service.create(body);
    //     return resp
    //         .status(200)
    //         .send(ser);
    // }

    // async getService(req, resp) {
    //     await sequelize.sync({ force: false });
    //     const services = await service.findAll();
    //     return resp
    //         .status(200)
    //         .send(services);}


    async getUser(req, resp) {
        await sequelize.sync({ force: false });
        const user = await userinformation.findAll();
        return resp
            .status(200)
            .send(user);}

    async createUser(req, resp) {
        const user = req.body;

        await sequelize.sync({ force: false });

        const findUser = await userinformation.findOne({

            where: { email: user.email },

        });

        if (findUser !== null) {

            return resp

                .status(409)

                .send({ message: `User ${user.email} is already present` });

        }

        const userCreated = await userinformation.create({

            customername: user.customername,
            userpassword: user.userpassword,
            state: user.state,
            city: user.city,
            email: user.email,
            address: user.address,
            roleid: '5',
            primarycontactnumber: user.primarycontactnumber,
            mobilenumber: user.mobilenumber,
        });

        return resp

            .status(201)

            .send({ message: `User ${user.username} is registered successfully` });

    }



}



export default AuthLogic;