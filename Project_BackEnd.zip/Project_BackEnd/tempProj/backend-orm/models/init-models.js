import _sequelize from "sequelize";
const DataTypes = _sequelize.DataTypes;
import _totalservices from  "./totalservices.js";

export default function initModels(sequelize) {
  const totalservices = _totalservices.init(sequelize, DataTypes);

  totalservices.belongsTo(service, { as: "service", foreignKey: "serviceid"});
  service.hasMany(totalservices, { as: "totalservices", foreignKey: "serviceid"});
  totalservices.belongsTo(userinformation, { as: "customer", foreignKey: "customerid"});
  userinformation.hasMany(totalservices, { as: "totalservices", foreignKey: "customerid"});

  return {
    totalservices,
  };
}
