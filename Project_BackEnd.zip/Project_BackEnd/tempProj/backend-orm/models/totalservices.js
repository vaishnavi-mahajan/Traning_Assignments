import _sequelize from 'sequelize';
const { Model, Sequelize } = _sequelize;

export default class totalservices extends Model {
  static init(sequelize, DataTypes) {
  return super.init({
    totalserviceid: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    vehicletypeid: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    customerid: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'userinformation',
        key: 'customerid'
      }
    },
    serviceid: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'service',
        key: 'serviceid'
      }
    }
  }, {
    sequelize,
    tableName: 'totalservices',
    schema: 'public',
    timestamps: false,
    indexes: [
      {
        name: "totalservices_pkey",
        unique: true,
        fields: [
          { name: "totalserviceid" },
        ]
      },
    ]
  });
  }
}
