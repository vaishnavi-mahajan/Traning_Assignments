var express = require("express");
var router = express.Router();

router.post('',function(request,response,next){
    console.log("called post server")
    response.send({"hello":["kajal"," kanade"]})
});

module.exports = router;