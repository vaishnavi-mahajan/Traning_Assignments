import logo from './logo.svg';
import './App.css';
import LoginFormComponent from "./component/loginform"
import {BrowserRouter as Router} from 'react-router-dom';
import "./../node_modules/bootstrap/dist/css/bootstrap.min.css";
import SignUpComponent from "./component/signup";
import { Route, Routes } from "react-router";
import DashboardComponent from "./component/dashboard";
import Home from "./component/home";
import About from "./component/About";
import Contact from "./component/contact"
import Bill from './component/bill';
import Status from './component/status';
// import navbar from './component/navbar';
import './CSS/App.css'

function App() {
  const PageNotFound = () =>(
    <div>
      404!
    </div>
  )

  
  return (

  
    <Router>
      <Routes>
      <Route exact path ="/" element={<Home/>}></Route>
        <Route exact path ="/About" element={<About/>}></Route>
        <Route exact path ="/Contact" element={<Contact/>}></Route>
        <Route exact path ="/loginform" element={<LoginFormComponent/>}></Route>
        <Route exact path ="/signup" element={<SignUpComponent/>}></Route>
        <Route exact path ="/dashboard" element={<DashboardComponent/>}></Route>
        <Route exact path ="/bill" element={<Bill/>}></Route>
        <Route exact path ="/status" element={<Status/>}></Route>
        
        {/* <Route NavLink path="/login" element={<Login />} /> */}
        <Route  element={<PageNotFound/>}></Route>

      </Routes>
    </Router>

    // <Router>
    //   <navbar />
    //   <Switch>
    //     <Route path='/' exact component={Home} />
    //     <Route path='/about' component={About} />
    //     <Route path='/signup' component={SignUpComponent} />
    //     <Route path='/loginfrom' component={LoginFormComponent} />
    //   </Switch>
    // </Router>
   // <LoginFormComponent></LoginFormComponent>
  );
}

export default App;
