import { useNavigate } from "react-router-dom";
import React from "react";
import Home  from "./home";


const About = () => {
    const navigate = useNavigate();
    return (
        <div className="container">
            <div className="py-4">
                <h1>Welcome to About us</h1>
                <h4>A motor vehicle service or tune-up is a series of maintenance procedures carried out at a set time interval or after the vehicle has traveled a certain distance. The service intervals are specified by the vehicle manufacturer in a service schedule and some modern cars display the due date for the next service electronically on the instrument panel.
</h4>


{/* <button style={{display: 'flex', flexDirection: 'column', alignItems:'center', color:'white'}} onClick={()=> {
    navigate('/')
  }}>Home</button> */}

<button type="submit" className="btn btn-primary"
                         onClick={()=> {
                            navigate('/')
                          }}>Home</button>
            </div>
        </div>
    )
};
export default About;