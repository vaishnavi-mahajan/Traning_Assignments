import { useNavigate } from "react-router-dom";
import React from "react";
import Home  from "./home";


const Contact = () => {
    const navigate = useNavigate();
    return (
        <div className="container">
            <div className="py-4">
                <h1>Contact us</h1>
                <h4>Vaishnavi Mahajan</h4>
                <h4>Contact No: 9765745530</h4>


{/* <button style={{display: 'flex', flexDirection: 'column', alignItems:'center', color:'white'}} onClick={()=> {
    navigate('/')
  }}>Home</button> */}


<button type="submit" className="btn btn-primary"
                         onClick={()=> {
                            navigate('/')
                          }}>Home</button>
            </div>
        </div>
    )
};
export default Contact;