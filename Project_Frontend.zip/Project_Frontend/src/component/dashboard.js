import React from 'react';
import { useState } from "react";
import { Button, Form, FormGroup, Label, Input, Span } from 'reactstrap';
import { useNavigate } from 'react-router-dom';
import Status from './status';
import Bill from './bill';
import Home from './home';


const Dashboard = () => {
  const [vehicleNumber, setVehicleNumber] = useState("");

  const [vehicleType, setVehicleType] = useState("");

  const [vehicleNo, setVehicleNo] = useState("");
    const navigate = useNavigate();

    const book = () =>{

      const obj = {

          vehicleNumber:vehicleNumber,

          customerId: 2,

          serviceId:1,

          vehicleType:'Truck',

          vehicleTypeId:1

      };

      bookAService(obj)

      // getTotalServicesByCustomerId("2");   
     }

const bookAService = (bookService) => {

      console.log(bookService)

      // POST request using fetch()

      fetch("http://localhost:7013/api/bookService", {

          method: "POST",

          body: JSON.stringify({

              vehiclenumber: bookService.vehicleNumber,

              customerid: bookService.customerId,

              statusid: 1,

              serviceId: bookService.serviceId,
              serviceregistrationdate: new Date(),

              vehicletype: bookService.vehicleType,

              vehicleTypeId: bookService.vehicleTypeId,

          }),

          headers: {

              "Content-type": "application/json; charset=UTF-8"

          }

      })



          // Converting to JSON

          .then(response => response.json())



          // Displaying results to console

          .then(json => {

              console.log("Service is booked");

              alert("Your Service is booked");

          });

      // navigate("/home");

  }

    
    return (
              
        <div className="container">
               <h1>Select Services</h1>

              
               <div class="col-8">
                <label for="inputAddress2" class="form-label" >Vehicle Type</label>
                <input type="text" size="50" class="form-control" id="vehicletype" placeholder="Car,Truck" onChange={(e)=>setVehicleNumber(e.target.value)}/>
            </div>
            <div class="col-md-8">
                <label for="inputCity" class="form-label">Vehicle No</label>
                <input type="text" class="form-control" id="inputCity" placeholder="MH29BA6062"onChange={(e)=>setVehicleNo(e.target.value)}/>
            </div>
            <div class="col-md-8">
                <label for="inputState" class="form-label">Service Type</label>
                <input type="text" class="form-control" id="inputCity" placeholder="Washing"onChange={(e)=>setVehicleType(e.target.value)}/>

                {/* <select id="inputState" class="form-select" onChange={(e)=>setVehicleType(e.target.value)}>
                    <option selected>Choose...</option>
                    <option value="maharashtra">Washing</option>
                    <option value="Kerala">Oiling</option>
                    <option value="gujrat">Part Change</option>
                    <option value="telangana">Cleaning</option>
                   
                </select> */}
               
            </div>
<div></div>

            {/* <button style={{display: 'flex', flexDirection: 'column', alignItems:'center'}} onClick={()=> {
    navigate('/status')
  }}>Check Status</button> */}

<button type="submit" className="btn btn-primary"
                         onClick={book}>Booked</button>

<button type="submit" className="btn btn-primary"
                         onClick={()=> {
                            navigate('/status')
                          }}>Check Status</button>

<button type="submit" className="btn btn-primary"
                         onClick={()=> {
                            navigate('/bill')
                          }}>Pay Bill</button>


<button type="submit" className="btn btn-primary"
                         onClick={()=> {
                            navigate('/')
                          }}>Home</button>
                

{/* <button style={{display: 'flex', flexDirection: 'column', alignItems:'center'}} onClick={()=> {
    navigate('/bill')
  }}>Pay Bill</button> */}

{/* 
<button style={{display: 'flex', flexDirection: 'column', alignItems:'center'}} onClick={()=> {
    navigate('/')
  }}>Home</button> */}
            </div>


         );
};

export default Dashboard;