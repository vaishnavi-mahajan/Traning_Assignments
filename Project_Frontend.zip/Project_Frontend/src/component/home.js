import { useNavigate } from "react-router-dom";

const Home = () => {
  const navigate = useNavigate();
  
    return (
      
        <div class="col-md-12" style={{padding:100,  justifyContent: "center",
        alignItems: "center", 
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          // backgroundColor: "gray",
          
        }}> 
          
{/* { flexDirection: "row" ,marginLeft: 20, justifyContent: 'space-evenly' } */}

<div className="header">

<div class="bg-info col-sm-6">
<h1 style={{color: "Black", fontSize: '6em', textAlign:'center'}}>Welcome to Perfect Services</h1>
</div>

{/* <button style={{width: '10%',color:'Black',
      height: 30, display: 'flex', flexDirection: 'column', alignItems:'center'}} onClick={()=> {
    navigate('/about')
  }}>About</button> */}
 <div class="bg-info col-sm-4">
  
<button type="submit" className="btn btn-primary"
                         onClick={()=> {
                            navigate('/about')
                          }}>About</button>


<button type="submit" className="btn btn-primary"
                         onClick={()=> {
                            navigate('/contact')
                          }}>Contact</button>


<button type="submit" className="btn btn-primary"
                         onClick={()=> {
                            navigate('/signup')
                          }}>SignUp</button>


<button type="submit" className="btn btn-primary"
                         onClick={()=> {
                            navigate('/loginform')
                          }}>Login</button>
                           </div>

{/* <button style={{width: '10%', color:'white',
      height: 30,display: 'flex', flexDirection: 'column', alignItems:'center', position:'left'}} onClick={()=> {
    navigate('/contact')
  }}>Contact</button> */}

{/* <button style={{display: 'flex', flexDirection: 'column', alignItems:'right'}} onClick={()=> {
    navigate('/selectvehicle')
  }}>selectvehicle</button> */}
           

    {/* <button style={{width: '10%',color:'white',
      height: 30,display: 'flex', flexDirection: 'column', alignItems:'center', position:'right'}} onClick={()=> {
    navigate('/signup')
  }}>SignUp</button> */}
{ }
{/* <button style={{width: '10%',color:'white',
      height: 30,display: 'flex', flexDirection: 'column', alignItems:'center'}} onClick={()=> {
    navigate('/loginform')
  }}>Login</button> */}


</div>
        </div>
        
    )

    



}
export default Home;