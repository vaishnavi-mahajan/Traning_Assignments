import React from 'react';
import { useState } from "react";
import {Button,Form,FormGroup,Label,Input,Span} from 'reactstrap';


const ServicingComponent = () => {

    

    return (
               <div>
           <h1>Inside ServicingComponent </h1>
        </div>
     

    
      

    );
};

export default ServicingComponent;