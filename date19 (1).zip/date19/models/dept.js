import _sequelize from 'sequelize';
const { Model, Sequelize } = _sequelize;

export default class dept extends Model {
  static init(sequelize, DataTypes) {
  super.init({
    deptno: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    deptname: {
      type: DataTypes.STRING(100),
      allowNull: false,
      primaryKey: true
    }
  }, {
    sequelize,
    tableName: 'dept',
    schema: 'public',
    timestamps: false,
    indexes: [
      {
        name: "dept_pkey",
        unique: true,
        fields: [
          { name: "deptname" },
        ]
      },
    ]
  });
  return dept;
  }
}
