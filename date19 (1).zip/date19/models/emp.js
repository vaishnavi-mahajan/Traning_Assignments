import _sequelize from 'sequelize';
const { Model, Sequelize } = _sequelize;

export default class emp extends Model {
  static init(sequelize, DataTypes) {
  super.init({
    empno: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    empname: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    deptname: {
      type: DataTypes.STRING(100),
      allowNull: false,
      references: {
        model: 'dept',
        key: 'deptname'
      }
    },
    designation: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    salary: {
      type: DataTypes.BIGINT,
      allowNull: false
    }
  }, {
    sequelize,
    tableName: 'emp',
    schema: 'public',
    timestamps: false,
    indexes: [
      {
        name: "emp_pkey",
        unique: true,
        fields: [
          { name: "empno" },
        ]
      },
    ]
  });
  return emp;
  }
}
