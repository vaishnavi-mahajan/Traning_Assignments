import _sequelize from "sequelize";
const DataTypes = _sequelize.DataTypes;
import _dept from  "./dept.js";
import _emp from  "./emp.js";

export default function initModels(sequelize) {
  const dept = _dept.init(sequelize, DataTypes);
  const emp = _emp.init(sequelize, DataTypes);

  emp.belongsTo(dept, { as: "deptname_dept", foreignKey: "deptname"});
  dept.hasMany(emp, { as: "emps", foreignKey: "deptname"});

  return {
    dept,
    emp,
  };
}
