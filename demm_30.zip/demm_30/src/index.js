// imporing the React Modules the ES 6 Concept of Module Export and Import

import React from 'react';

import ReactDOM from 'react-dom';


import './index.css';

import reportWebVitals from './reportWebVitals';
// import the redux and react-redux object model

import {createStore} from 'redux';

import {Provider} from 'react-redux';

import reducers from './../src/reduxapp/reducers/reducers';

import MainReduxComponent from './../src/reduxapp/mainreduxcomponent';
import "./../node_modules/bootstrap/dist/css/bootstrap.min.css";


let store = createStore(reducers, window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ && window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__());



ReactDOM.render(

  <React.StrictMode>

    {/* the MainReduxComponent will now have its lifecycle under the redux store*/}

      <Provider store={store}>

        <MainReduxComponent></MainReduxComponent>

      </Provider>

  </React.StrictMode>,

  document.getElementById('root')

);

reportWebVitals();