export const Departments = ["IT", "HR", "SALES", "ACCOUNTS", "TRAINING", "ADMIN"];

export const Designations = ["Manager", "Engineer", "Operator", "Lead", "Sr. Manager"];