import {combineReducers} from 'redux';
export const addDepartmentReducer=(state,action)=>{
    console.log('In Add Reducer');
    switch(action.type) {
        case 'ADD_DEPARTMENT':
            // the state will contain tthew newly created department object
            return {
                department: action.department // this is returned from 
                // the addDepartment action see actions.js
            };
        default:
             return state; // return a default state       
    }
};


export const listDepartmentsReducer=(state=[], action)=>{
    console.log('In List Reducer');
    switch(action.type){
        case 'ADD_DEPARTMENT':
            
            return [...state, addDepartmentReducer(undefined,action)];
        default:
            return state;    
    }   
}

export const selectDepartmentReducer=(state,action) =>{
    switch(action.type) {
       case 'SELECT_DEPARTMENT': 
          return {
              department: action.department 
          }
        default: 
          state = {}
          return state; 
    }
  }


const reducers = combineReducers({listDepartmentsReducer, selectDepartmentReducer});

export default reducers;