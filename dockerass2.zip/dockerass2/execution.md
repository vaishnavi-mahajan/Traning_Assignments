For microservices

    - docker-compose up

For k8slocal

PS C:\Users\vaishnavi.mahajan\Downloads\dockerass2\microservices> cd k8slocal
PS C:\Users\vaishnavi.mahajan\Downloads\dockerass2\microservices\k8slocal> kubectl apply  -f deployment.yml
deployment.apps/servk8sdeploy created
PS C:\Users\vaishnavi.mahajan\Downloads\dockerass2\microservices\k8slocal> kubectl apply  -f service.yml
service/service created
PS C:\Users\vaishnavi.mahajan\Downloads\dockerass2\microservices\k8slocal> kubectl get pod
NAME                             READY   STATUS    RESTARTS   AGE
servk8sdeploy-58f8ffddcb-qjmn6   1/1     Running   0          53s
servk8sdeploy-58f8ffddcb-qrs9t   1/1     Running   0          53s