import express from "express";

const instance = express();
 
instance.use(express.json());
instance.use(express.urlencoded({extended:false}));

const port = process.env.PORT || 7021;

let student = [
  { stuNo: 101, stuName: "Vaishnavi", DeptName: "IT", Marks: 40 },
  { stuNo: 102, stuName: "Prathmesh", DeptName: "HR",  Marks: 98 },
  { stuNo: 103, stuName: "Sarthak", DeptName: "IT",  Marks: 56 },
  { stuNo: 104, stuName: "Raghav", DeptName: "HR", Marks: 80 },
  { stuNo: 105, stuName: "Chaitanya", DeptName: "IT", Marks: 60 },
];

// Lets add REST API Methods using HTTP methods of 'instance'

instance.get("/api/student", (req, resp) => {
  resp.status(200).send({
    message: "Data reading is successful",
    records: JSON.stringify(student),
  });
});
instance.get("/api/student/:id", (req, resp) => {
  // read the URL parameter
  let id = parseInt(req.params.id);
  if (id === 0) {
    resp
      .status(500)
      .send({
        message:
          "Based on Parameter we cannot Process your request, please check data",
      });
  } else {
    let stu = student.find((e, i) => {
      return e.stuNo === id;
    });
    resp
      .status(200)
      .send({
        message: "Data reading is successful",
        record: JSON.stringify(stu),
      });
  }
});
instance.post("/api/student", (req, resp) => {
  // read data from body
  let stu = req.body;
  console.log(`Received Data for post is = ${JSON.stringify(stu)}`);
  student.push(stu);
  resp
    .status(200)
    .send({
      message: "Data reading is successful",
      record: student,
    });
});
 
instance.listen(port, () => {
  console.log(`Server Started on Port ${port}`);
});
