import express from "express";

const instance = express();
 
instance.use(express.json());
instance.use(express.urlencoded({extended:false}));

const port = process.env.PORT || 7022;

let user = [
  { UserId: 101, UserName: "John", Occupation: "IT", Income: 11000 },
  { UserId: 102, UserName: "Sam", Occupation: "HR", Income: 12000 },
  { UserId: 103, UserName: "Jack", Occupation: "IT", Income: 13000 },
  { UserId: 104, UserName: "Robert", Occupation: "HR", Income: 14000 },
  { UserId: 105, UserName: "Liza", Occupation: "IT", Income: 15000 },
];

// Lets add REST API Methods using HTTP methods of 'instance'

instance.get("/api/user", (req, resp) => {
  resp.status(200).send({
    message: "Data reading is successful",
    records: JSON.stringify(user),
  });
});
instance.get("/api/user/:id", (req, resp) => {
  // read the URL parameter
  let id = parseInt(req.params.id);
  if (id === 0) {
    resp
      .status(500)
      .send({
        message:
          "Based on Parameter we cannot Process your request, please check data",
      });
  } else {
    let per = user.find((e, i) => {
      return e.UserId === id;
    });
    resp
      .status(200)
      .send({
        message: "Data reading is successful",
        record: JSON.stringify(per),
      });
  }
});
instance.post("/api/user", (req, resp) => {
  // read data from body
  let per = req.body;
  console.log(`Received Data for post is = ${JSON.stringify(per)}`);
  user.push(per);
  resp
    .status(200)
    .send({
      message: "Data reading is successful",
      record: user,
    });
});
 
instance.listen(port, () => {
  console.log(`Server Started on Port ${port}`);
});
