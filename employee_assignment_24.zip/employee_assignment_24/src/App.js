import EmployeeFormComponent from './../src/components/formcomponent/employeeformcomponent_withoutvalidation';
import DataGridComponent from './../src/components/reusablecomponents/datagridcomponent';
import DropdownComponent from './../src/components/reusablecomponents/dropdowncomponent';
// import EmployeeFormValidationComponent from './comp/formcomponent/employeeformcomponent'
 //import EmployeeFormComponent from './comp/formcomponent/formcomponentwithoutvalidation'


//import './App.css';

function App() {
  return (
    <div className="App">
     <EmployeeFormComponent></EmployeeFormComponent>
     {/* <DataGridComponent></DataGridComponent> */}
     {/* <DropdownComponent></DropdownComponent> */}
     {/* <EmployeeFormValidationComponent></EmployeeFormValidationComponent> */}



    </div>
  );
}

export default App;
