import styles from './datagrid.styles.css'
import { useState,useEffect } from 'react';
const DataGridComponent=(props)=>{
    const [j, setJ] = useState(0)
    
    
    const rowClick=(row)=>{
        props.getSelectedRow(row);
        console.log(`Selected Row ${JSON.stringify(row)}`);
    }
   function onNext(){
        if((j+props.pages)<props.dataSource.length){
            setJ(j+props.pages);
        }
   }
   function onPrev(){
    if((j-props.pages)>=0){
        setJ(j-props.pages);
    }
   }
    
    if(props.dataSource === undefined || props.dataSource.length === 0 ) {
        return (
            <div className="container">
                 <strong>
                    No records to display
                 </strong>   
            </div>
        );
    } else {

        //Comparer Function    
            function GetSortOrder(prop) {    
                return function(a, b) {    
                    if (a[prop] > b[prop]) {    
                        return 1;    
                    } else if (a[prop] < b[prop]) {    
                        return -1;    
                    }    
                    return 0;    
                }    
            } 
        // 1. read all keys
        //if sort key
        if(props.canSort){
            if(props.sortKey=='empNo'){
                props.dataSource.sort(GetSortOrder('empno'))

            }
            else if(props.sortKey=='empName'){
                props.dataSource.sort(GetSortOrder('empname'))
            }
            else if(props.sortKey=='designation'){
                props.dataSource.sort(GetSortOrder('designation'))
            }
            else if(props.sortKey=='salary'){
                props.dataSource.sort(GetSortOrder("salary"))
            }
            else if(props.sortKey=='deptname'){
                props.dataSource.sort(GetSortOrder("deptname"))
            }
        }

        function groupArrayOfObjects(arr, criteria) {
            
            const newObj = arr.forEach((acc, currentValue)=> {
              if (!acc[currentValue[criteria]]) {
                acc[currentValue[criteria]] = [];
              }
              acc[currentValue[criteria]].push(currentValue);
              return acc;
            }, {});
            return newObj;
          }
        //if group key
          if(props.canGroup){
              
            if(props.sortKey=='deptname'){
                props.dataSource.sort(GetSortOrder("deptname"))
            
            }
          }

          
          
         
          
        const columns  = Object.keys(props.dataSource[0]);
        console.log(props);
       return ( <div><table >
            <thead>
                <tr>
                    {
                        columns.map((c,i)=>(
                            <th key={i}>
                                {c}
                            </th>
                        ))
                    }
                </tr>
            </thead>
            <tbody>
                {
                    props.dataSource.slice(j,j+props.pages).map((row,rIndex)=>(
                        <tr key={rIndex} onClick={()=>rowClick(row)}>
                            {
                                 columns.map((col,cIndex)=>(
                                    <td key={cIndex}>
                                        {row[col]}
                                    </td>
                                   
                                ))
                               
                            }
                            
                             {props.canDelete
                             ?<button type="button" onClick={()=>props.handleDelete(rIndex)}>Delete</button>
                             :<td>Cant Delete</td> }

                                
                            
                        </tr>
                    ))
                }
            </tbody>
            
        </table>
        <button onClick={onPrev}>previous</button>
        <button onClick={onNext}>next</button>
        </div>);
    } 

    
};

export default DataGridComponent;