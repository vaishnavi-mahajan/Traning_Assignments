import React,{useState} from 'react'
import { useLocation ,useNavigate} from "react-router-dom";
export default function Login(props) {

    const [email, setemail] = useState();
    const [pass, setpass] = useState()
    //const prod = props.location.state
    const location = useLocation();
  console.log(location.state);
   const navigate = useNavigate();
    return (
        <div style={{padding:100}}>
            <div >Login</div>
            <div style={{margin:20}}>
                <input type='text' placeholder='email' onChange={(evt)=>setemail(evt.target.value)}/>
            
            </div>
            <div style={{margin:20}}>
                <input type='text' placeholder='password' onChange={(evt)=>setpass(evt.target.value)}/>
            
            </div>
            <button style={{margin:20}} onClick={()=> {
               // console.log("props:"+prod)
               if(location.state.email===email && location.state.pass===pass) {
                navigate("/employee");
               }else{
                  
                   return(alert("Login unsuccesfull"))
               }
                    
  }}>Login</button>
           
        </div>
    )
}
